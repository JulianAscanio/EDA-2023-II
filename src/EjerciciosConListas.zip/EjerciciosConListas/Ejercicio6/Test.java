/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosConListas.Ejercicio6;
import java.util.*;
/**
 *
 * @author Royner Omaña
 */
public class Test {
    public static void main(String[] args) {
        
        Cedula cedulaManager = new Cedula();
        
        //Lista Cedulas

        cedulaManager.agregarCedula(19144473);
        cedulaManager.agregarCedula(19145954);
        cedulaManager.agregarCedula(19456789);
        cedulaManager.agregarCedula(19234567);
        cedulaManager.agregarCedula(19567890);
        cedulaManager.agregarCedula(19011223);
        cedulaManager.agregarCedula(19455678);
        cedulaManager.agregarCedula(19387654);
        cedulaManager.agregarCedula(19555555);
        cedulaManager.agregarCedula(19111112);
        cedulaManager.agregarCedula(19499988);
        cedulaManager.agregarCedula(19244433);
        cedulaManager.agregarCedula(19577766);
        cedulaManager.agregarCedula(19088887);
        cedulaManager.agregarCedula(19166644);
        cedulaManager.agregarCedula(19322211);
        cedulaManager.agregarCedula(19433322);
        cedulaManager.agregarCedula(19244445);
        cedulaManager.agregarCedula(19566677);
        cedulaManager.agregarCedula(19188889);
        cedulaManager.agregarCedula(19212121);
        cedulaManager.agregarCedula(19434343);
        cedulaManager.agregarCedula(19156565);
        cedulaManager.agregarCedula(19478787);
        cedulaManager.agregarCedula(19598989);
        cedulaManager.agregarCedula(19111110);
        cedulaManager.agregarCedula(19422220);
        cedulaManager.agregarCedula(19333300);
        cedulaManager.agregarCedula(19544440);
        cedulaManager.agregarCedula(19255550);
        cedulaManager.agregarCedula(19466660);
        cedulaManager.agregarCedula(19177770);
        cedulaManager.agregarCedula(19088880);
        cedulaManager.agregarCedula(19399900);
        cedulaManager.agregarCedula(19510000);
        cedulaManager.agregarCedula(19121212);
        cedulaManager.agregarCedula(19423232);
        cedulaManager.agregarCedula(19234343);
        cedulaManager.agregarCedula(19545454);
        cedulaManager.agregarCedula(19056565);
        cedulaManager.agregarCedula(19467676);
        cedulaManager.agregarCedula(19378787);
        cedulaManager.agregarCedula(19589898);
        cedulaManager.agregarCedula(19101010);
        cedulaManager.agregarCedula(19420202);
        cedulaManager.agregarCedula(19230303);
        cedulaManager.agregarCedula(19540404);
        cedulaManager.agregarCedula(19050505);
        cedulaManager.agregarCedula(19460606);
        cedulaManager.agregarCedula(19370707);
        cedulaManager.agregarCedula(19580808);
        cedulaManager.agregarCedula(19190909);
        cedulaManager.agregarCedula(19412121);
        cedulaManager.agregarCedula(19223232);
        cedulaManager.agregarCedula(19534343);
        cedulaManager.agregarCedula(19045454);
        cedulaManager.agregarCedula(19156565);
        cedulaManager.agregarCedula(19367676);
        cedulaManager.agregarCedula(19478787);
        cedulaManager.agregarCedula(19289898);
        cedulaManager.agregarCedula(19510101);
        cedulaManager.agregarCedula(19121212);
        cedulaManager.agregarCedula(19423232);
        cedulaManager.agregarCedula(19234343);
        cedulaManager.agregarCedula(19545454);
        cedulaManager.agregarCedula(19056565);
        cedulaManager.agregarCedula(19467676);
        cedulaManager.agregarCedula(19378787);
        cedulaManager.agregarCedula(19589898);
        cedulaManager.agregarCedula(19101010);
        cedulaManager.agregarCedula(19420202);
        cedulaManager.agregarCedula(19230303);
        cedulaManager.agregarCedula(19540404);
        cedulaManager.agregarCedula(19050505);
        cedulaManager.agregarCedula(19460606);
        cedulaManager.agregarCedula(19370707);
        cedulaManager.agregarCedula(19580808);
        
        //Metodos

        int posicion = cedulaManager.buscarCedula(19144473);
        if (posicion != -1) {
            System.out.println("La cedula 19144473 se encuentra en la posicion: " + posicion);
        } else {
            System.out.println("La cedula 19144473 no se encuentra en la lista.");
        }

        int cantidadMayores = cedulaManager.CedulasMayoresA(19145954);
        System.out.println("Cantidad de cedulas mayores a 19145954: " + cantidadMayores);
        }
    }

    