/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosConListas.Ejercicio6;
import java.util.*;

/**
 *
 * @author Royner Omaña
 */
public class Cedula<T extends Comparable<T>> {
    private Nodo<T> inicio;

    public Cedula() {
        this.inicio = null;
    }

    public void agregarCedula(T dato) {
        Nodo<T> nuevoNodo = new Nodo<>(dato);
        if (inicio == null) {
            inicio = nuevoNodo;
        } else {
            Nodo<T> actual = inicio;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
    }

    public int buscarCedula(T numeroCedula) {
        Nodo<T> actual = inicio;
        int posicion = 1;

        while (actual != null) {
            if (actual.getDato().equals(numeroCedula)) {
                return posicion;
            }
            actual = actual.getSiguiente();
            posicion++;
        }

        return -1; // Si no se encuentra la cédula en la lista
    }

    public int CedulasMayoresA(T numeroCedula) {
        int contador = 0;
        Nodo<T> actual = inicio;

        while (actual != null) {
            if (actual.getDato().compareTo(numeroCedula) > 0) {
                contador++;
            }
            actual = actual.getSiguiente();
        }

        return contador;
    }
}

