/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package EjerciciosConListas.Ejercicio5;

/**
 *
 * @author Royner Omaña
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        Viaje viaje = new Viaje("España");
        //Tipo 1 = Comida
        //Tipo 2 = Hospedaje
        //Tipo 3 = Transporte
        //Tipo 4 = Ropa 
        viaje.agregarGasto(new Gasto(1, 50000));  
        viaje.agregarGasto(new Gasto(2, 80000)); 
        viaje.agregarGasto(new Gasto(3, 100000));  
        viaje.agregarGasto(new Gasto(4, 60000));  
        viaje.agregarGasto(new Gasto(1, 40000));          

        for (int i = 1; i <= 4; i++) {
            double totalPorTipo = viaje.gastosTotalesPorTipo(i);
            System.out.println("Gastos totales en tipo " + i + ": " + totalPorTipo);
        }

        int cantidadComida = viaje.contarGastosPorTipo(1);
        System.out.println("Cantidad de gastos en comida: " + cantidadComida);

        int tipoMasCostoso = viaje.gastoMayor();
        System.out.println("Tipo de gasto mas costoso: " + tipoMasCostoso);
    }
    
}
