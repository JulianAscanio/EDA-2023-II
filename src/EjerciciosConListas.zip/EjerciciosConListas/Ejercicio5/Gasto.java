/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosConListas.Ejercicio5;

/**
 *
 * @author Royner Omaña
 */
public class Gasto {
    private int tipo;
    private double valor;

    public Gasto(int tipo, double valor) {
        this.tipo = tipo;
        this.valor = valor;
    }

    public int getTipo() {
        return tipo;
    }

    public double getValor() {
        return valor;
    }
}
