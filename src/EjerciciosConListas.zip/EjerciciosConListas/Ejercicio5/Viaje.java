/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EjerciciosConListas.Ejercicio5;

/**
 *
 * @author Royner Omaña
 */
public class Viaje {
    private Nodo<Gasto> inicio;
    

    public Viaje(String destino) {
        this.inicio = null;
    }

    public void agregarGasto(Gasto gasto) {
        Nodo<Gasto> nuevoNodo = new Nodo<>(gasto);
        if (inicio == null) {
            inicio = nuevoNodo;
        } else {
            Nodo<Gasto> actual = inicio;
            while (actual.getSiguiente() != null) {
                actual = actual.getSiguiente();
            }
            actual.setSiguiente(nuevoNodo);
        }
    }

    public double gastosTotalesPorTipo(int tipo) {
        double total = 0;
        Nodo<Gasto> actual = inicio;

        while (actual != null) {
            if (actual.getDato().getTipo() == tipo) {
                total += actual.getDato().getValor();
            }
            actual = actual.getSiguiente();
        }

        return total;
    }

    public int contarGastosPorTipo(int tipo) {
        int contador = 0;
        Nodo<Gasto> actual = inicio;

        while (actual != null) {
            if (actual.getDato().getTipo() == tipo) {
                contador++;
            }
            actual = actual.getSiguiente();
        }

        return contador;
    }

    public int gastoMayor() {
        int tipoMasCostoso = -1;
        double maxMonto = 0;
        Nodo<Gasto> actual = inicio;

        while (actual != null) {
            if (actual.getDato().getValor() > maxMonto) {
                maxMonto = actual.getDato().getValor();
                tipoMasCostoso = actual.getDato().getTipo();
            }
            actual = actual.getSiguiente();
        }

        return tipoMasCostoso;
    }
}
